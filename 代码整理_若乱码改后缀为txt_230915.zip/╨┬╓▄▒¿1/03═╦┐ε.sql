insert into ads_ag_kbh_report_weekly (`FirstDay`, `ReportType`, `Team`, `Staff`, `Year`, `Month`, `Week`, 
	RefundRate )
select '${StartDay}' ,'${ReportType}' ,Department ,'�ϼ�' ,year('${StartDay}') ,month('${StartDay}') ,WEEKOFYEAR('${StartDay}')+1
-- 	,B.FrozenAmount
	,ifnull(round(B.RefundUSDPrice / A.TotalGross, 4), 0) as RefundRate
from ads_ag_kbh_report_weekly A
join (
	select ifnull(ms.dep2,'��ٻ�') Department ,abs(round(sum((RefundAmount)/ExchangeUSD),2)) as RefundUSDPrice
	from wt_orderdetails wo
    join ( select case when NodePathName regexp  '�ɶ�' then '��ٻ�һ��' else '��ٻ�����' end as dep2,*
        from import_data.mysql_store where department regexp '��')  ms on ms.code=wo.shopcode and ms.department='��ٻ�'
    where wo.IsDeleted = 0 and TransactionType = '�˿�' and SettlementTime >='${StartDay}' and SettlementTime < '${NextStartDay}'
	group by grouping sets ((),(ms.dep2))
	union all 
	select NodePathName ,abs(round(sum((RefundAmount)/ExchangeUSD),2)) as RefundUSDPrice
	from wt_orderdetails wo
    join ( select case when NodePathName regexp  '�ɶ�' then '��ٻ�һ��' else '��ٻ�����' end as dep2,*
        from import_data.mysql_store where department regexp '��')  ms on ms.code=wo.shopcode and ms.department='��ٻ�'
    where wo.IsDeleted = 0 and TransactionType = '�˿�' and SettlementTime >='${StartDay}' and SettlementTime < '${NextStartDay}'
	group by NodePathName
	) B on A.Team = B.Department and A.FirstDay =  '${StartDay}' ;


