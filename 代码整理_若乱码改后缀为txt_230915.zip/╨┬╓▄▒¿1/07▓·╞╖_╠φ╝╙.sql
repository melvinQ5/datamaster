insert into ads_ag_kbh_report_weekly (`FirstDay`, `ReportType`, `Team`, `Staff`, `Year`, `Month`, `Week`,
	NewAddSpuCnt )
select '${StartDay}' ,'${ReportType}' ,ProjectTeam ,'�ϼ�' ,year('${StartDay}') ,month('${StartDay}') ,WEEKOFYEAR('${StartDay}')+1 as weeks
	,count(distinct wp.spu ) `����SPU��`
from import_data.erp_product_products wp
where Creationtime < '${NextStartDay}' and Creationtime >= '${StartDay}' and ProjectTeam = '��ٻ�' and IsMatrix=0 and status != 20
group by ProjectTeam;
/*
union all
select '${StartDay}' ,'${ReportType}' ,dep2 ,'�ϼ�' ,year('${StartDay}') ,month('${StartDay}') ,WEEKOFYEAR('${StartDay}')+1 as weeks
	,count(distinct wp.spu ) temp
from import_data.erp_product_products wp
left join ( select split(NodePathNameFull,'>')[2] as dep2 ,case when  NodePathName = '��Ʒ��' then '�����-��Ʒ��' else NodePathName end NodePathName	,name ,department
	from view_roles where ProductRole ='����' ) vr on wp.DevelopUserName = vr.name
where Creationtime < '${NextStartDay}' and Creationtime >= '${StartDay}' and ProjectTeam = '��ٻ�'  and IsMatrix=1 and status != 20
group by dep2;

 */

